# Zuul

Een simpele textadventure.

## Het spel spelen

**Stap 1: Installeer dotnet**

Installeer de laatste versie van [dotnet](https://dotnet.microsoft.com/en-us/download).
Of installeer de LTS versie (Long Term Support).

**Stap 2: Open een terminal**

Open deze folder in de terminal.
De folder bevat het Zuul.csproj bestand.

**Stap 3: Run het spel**

Typ dit commando:

```
dotnet run
```

Het spel start nu.
Veel plezier!
