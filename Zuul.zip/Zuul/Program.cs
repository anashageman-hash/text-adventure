class Program
{
	public static void Main(string[] args)
	{
		// Create and play the Game.
		Game game = new Game();
		game.Play();
	}
}
